Spanish mobile home-screen icon files

Upload all files in this folder to the same folder as your website's main index.html file.

Then paste the contents of head-code-to-add.html inside the <head> section of your homepage HTML.

The phone home-screen label will be: Spanish

Included files:
- manifest.json for Android/Chrome home-screen installs
- apple-touch-icon.png for iPhone/iPad home-screen icons
- icon-192.png and icon-512.png for Android/PWA installs
- favicon files for browser tabs
